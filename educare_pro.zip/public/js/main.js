// Aquí puedes agregar JS extra (por ejemplo, para calendario con /api/events)
console.log('EduCare Pro listo.');
