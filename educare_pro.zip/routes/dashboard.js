const express = require('express');
const router = express.Router();
const db = require('../db');

function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

router.get('/', requireAuth, (req, res) => {
  const user = req.session.user;

  // Cursos del usuario
  const sqlCourses = user.role === 'teacher'
    ? `SELECT c.* FROM courses c WHERE c.teacher_id = ?`
    : `SELECT c.* FROM courses c
       JOIN enrollments e ON e.course_id = c.id
       WHERE e.user_id = ?`;

  db.all(sqlCourses, [user.id], (err, courses) => {
    if (err) {
      console.error(err);
      courses = [];
    }

    // Próximas tareas (simple)
    const sqlAssignments = `
      SELECT a.*, c.title as course_title
      FROM assignments a
      JOIN courses c ON c.id = a.course_id
      JOIN enrollments e ON e.course_id = c.id
      WHERE e.user_id = ?
      ORDER BY a.due_date ASC
      LIMIT 5;
    `;

    db.all(sqlAssignments, [user.id], (err2, assignments) => {
      if (err2) {
        console.error(err2);
        assignments = [];
      }

      // Anuncios recientes
      const sqlAnnouncements = `
        SELECT an.*, c.title as course_title
        FROM announcements an
        JOIN courses c ON c.id = an.course_id
        ORDER BY an.created_at DESC
        LIMIT 5;
      `;
      db.all(sqlAnnouncements, [], (err3, announcements) => {
        if (err3) {
          console.error(err3);
          announcements = [];
        }

        res.render('dashboard/index', {
          user,
          courses,
          assignments,
          announcements
        });
      });
    });
  });
});

module.exports = router;
