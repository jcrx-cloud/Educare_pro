const express = require('express');
const router = express.Router();
const db = require('../db');

function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

function requireTeacher(req, res, next) {
  if (!req.session.user || (req.session.user.role !== 'teacher' && req.session.user.role !== 'admin')) {
    return res.redirect('/dashboard');
  }
  next();
}

// Crear tarea
router.post('/course/:courseId', requireTeacher, (req, res) => {
  const { title, description, due_date, points } = req.body;
  const courseId = req.params.courseId;

  db.run(`INSERT INTO assignments (course_id, title, description, due_date, points)
          VALUES (?, ?, ?, ?, ?)`,
    [courseId, title, description, due_date, points || 100],
    (err) => {
      if (err) {
        console.error(err);
        req.flash('error', 'No se pudo crear la tarea.');
      } else {
        req.flash('success', 'Tarea creada.');
      }
      res.redirect('/courses/' + courseId);
    });
});

// Ver tarea
router.get('/:id', requireAuth, (req, res) => {
  const assignmentId = req.params.id;
  const user = req.session.user;

  db.get(`SELECT a.*, c.title as course_title
          FROM assignments a
          JOIN courses c ON c.id = a.course_id
          WHERE a.id = ?`, [assignmentId], (err, assignment) => {
    if (err || !assignment) {
      console.error(err);
      req.flash('error', 'Tarea no encontrada.');
      return res.redirect('/dashboard');
    }

    if (user.role === 'teacher' || user.role === 'admin') {
      // Ver entregas
      db.all(`SELECT s.*, u.name as student_name
              FROM submissions s
              JOIN users u ON u.id = s.student_id
              WHERE s.assignment_id = ?`, [assignmentId], (err2, submissions) => {
        if (err2) {
          console.error(err2);
          submissions = [];
        }
        res.render('assignments/show_teacher', { user, assignment, submissions });
      });
    } else {
      // Ver entrega del estudiante
      db.get(`SELECT * FROM submissions WHERE assignment_id = ? AND student_id = ?`,
        [assignmentId, user.id], (err3, submission) => {
          if (err3) {
            console.error(err3);
            submission = null;
          }
          res.render('assignments/show_student', { user, assignment, submission });
        });
    }
  });
});

// Enviar tarea (estudiante)
router.post('/:id/submit', requireAuth, (req, res) => {
  const assignmentId = req.params.id;
  const studentId = req.session.user.id;
  const { text, file_url } = req.body;

  db.get(`SELECT * FROM submissions WHERE assignment_id = ? AND student_id = ?`,
    [assignmentId, studentId], (err, existing) => {
      if (err) {
        console.error(err);
        req.flash('error', 'Error al enviar la tarea.');
        return res.redirect('/assignments/' + assignmentId);
      }

      if (existing) {
        db.run(`UPDATE submissions SET text=?, file_url=?, submitted_at=CURRENT_TIMESTAMP WHERE id=?`,
          [text, file_url, existing.id],
          (err2) => {
            if (err2) {
              console.error(err2);
              req.flash('error', 'No se pudo actualizar la entrega.');
            } else {
              req.flash('success', 'Entrega actualizada.');
            }
            res.redirect('/assignments/' + assignmentId);
          });
      } else {
        db.run(`INSERT INTO submissions (assignment_id, student_id, text, file_url)
                VALUES (?, ?, ?, ?)`,
          [assignmentId, studentId, text, file_url],
          (err3) => {
            if (err3) {
              console.error(err3);
              req.flash('error', 'No se pudo registrar la entrega.');
            } else {
              req.flash('success', 'Tarea enviada.');
            }
            res.redirect('/assignments/' + assignmentId);
          });
      }
    });
});

// Calificar tarea
router.post('/:id/grade/:submissionId', requireTeacher, (req, res) => {
  const assignmentId = req.params.id;
  const submissionId = req.params.submissionId;
  const { grade, feedback } = req.body;

  db.run(`UPDATE submissions SET grade=?, feedback=?, graded_at=CURRENT_TIMESTAMP WHERE id=?`,
    [grade, feedback, submissionId],
    (err) => {
      if (err) {
        console.error(err);
        req.flash('error', 'No se pudo guardar la calificación.');
      } else {
        req.flash('success', 'Calificación guardada.');
      }
      res.redirect('/assignments/' + assignmentId);
    });
});

module.exports = router;
